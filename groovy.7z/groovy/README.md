# ReadyAPI4j Groovy DSL Samples

This module contains [sample recipes](src/test/groovy/com/smartbear/readyapi4j/samples/groovy) 
written with the [Groovy DSL](../../groovy-dsl).

Run these samples as described in the [samples module](../README.md)
