# ReadyAPI4j Java Samples

This module contains [sample recipes](src/test/java/com/smartbear/readyapi4j/samples/java) 
written with the [Fluent Java API](../../core). 

Run these samples as described in the [samples module](../README.md)
  

