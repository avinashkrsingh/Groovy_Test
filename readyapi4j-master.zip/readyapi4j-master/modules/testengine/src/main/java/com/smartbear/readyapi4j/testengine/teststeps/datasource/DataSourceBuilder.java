package com.smartbear.readyapi4j.testengine.teststeps.datasource;

import com.smartbear.readyapi4j.client.model.DataSource;

public interface DataSourceBuilder {
    DataSource build();
}
