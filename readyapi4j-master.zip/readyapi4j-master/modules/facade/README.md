# ReadyAPI4j Facade

The facade module provides a common entry-point to executing test recipes using either the local or remote execution engines.

See [Concepts](../../CONCEPTS.md#execution-facade) for usage.