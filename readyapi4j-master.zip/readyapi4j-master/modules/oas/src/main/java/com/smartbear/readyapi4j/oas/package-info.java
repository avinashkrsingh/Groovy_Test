/**
 * Swagger-related extensions to core API.
 */
package com.smartbear.readyapi4j.oas;