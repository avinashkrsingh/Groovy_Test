/**
 * Maven plugin classes.
 */
package com.smartbear.readyapi4j.maven;