# ReadyAPI4j Local executor

The local module provides a test execution engine that utilizes the [Open Source SoapUI core](https://github.com/SmartBear/soapui) for executing
recipes.

See [Concepts](../../CONCEPTS.md#local_execution) for more info.