## StepDefs for readyapi4j-cucumber

The actual StepDefs code for Cucumber API Tests - see the [main README](../../README.md) for a reference of 
the included vocabulary.