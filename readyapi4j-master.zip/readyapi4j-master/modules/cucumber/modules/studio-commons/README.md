## Cucumber Studio Commons

[ActionWord Annotation](src/main/java/com/smartbear/readyapi4j/cucumber/studio/ActionWord.java) used by the 
[Cucumber Studio Runner Import Command](../studio-runner/README.md#importing-actionwords) for extracting ActionWords 
from StepDefs - put in a separate module to avoid cyclic dependencies.