/**
 * Cucumber sample classes.
 */
package com.smartbear.cucumber.samples.extension;