## Utility classes for creating Cucumber StepDefs for readyapi4j-cucumber

Have a look at the declarative Cucumber sample in the [samples module](../samples) to see how these classes
can be used to create your own Gherkin vocabulary for readyapi4j-cucumber