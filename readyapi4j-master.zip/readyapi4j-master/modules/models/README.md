## ReadyAPI4j Models

This module generates required model classes from the old [TestServer API](https://app.swaggerhub.com/apis/smartbear/ready-api-testserver/2.2.0)  for recipe-related
code, and the new [TestEngine API](https://app.swaggerhub.com/apis/smartbear/readyapi-testengine/1.0.2) for remote execution.