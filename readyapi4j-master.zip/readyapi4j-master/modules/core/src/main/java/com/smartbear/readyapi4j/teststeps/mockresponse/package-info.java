/**
 * SOAP MockResponse TestStep classes.
 */
package com.smartbear.readyapi4j.teststeps.mockresponse;