/**
 * Common utilities.
 */
package com.smartbear.readyapi4j.support;