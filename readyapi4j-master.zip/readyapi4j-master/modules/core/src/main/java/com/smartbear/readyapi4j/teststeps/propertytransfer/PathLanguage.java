package com.smartbear.readyapi4j.teststeps.propertytransfer;

public enum PathLanguage {
    XPath, XQuery, JSONPath
}
