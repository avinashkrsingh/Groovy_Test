/**
 * Property-related classes and utilities.
 */
package com.smartbear.readyapi4j.properties;