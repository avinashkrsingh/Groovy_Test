/**
 * PropertyTransfer TestStep classes.
 */
package com.smartbear.readyapi4j.teststeps.propertytransfer;