/**
 * Root package containing core TestRecipe functionality.
 */

package com.smartbear.readyapi4j;