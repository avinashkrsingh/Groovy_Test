package com.smartbear.readyapi4j.auth;

import com.smartbear.readyapi4j.client.model.Authentication;

public interface AuthenticationBuilder {
    Authentication build();
}
