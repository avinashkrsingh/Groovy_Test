/**
 * Builders and utilities for HTTP Authentication functionality.
 */
package com.smartbear.readyapi4j.auth;