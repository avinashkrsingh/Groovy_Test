/**
 * Attachment builder and utilities.
 */
package com.smartbear.readyapi4j.attachments;