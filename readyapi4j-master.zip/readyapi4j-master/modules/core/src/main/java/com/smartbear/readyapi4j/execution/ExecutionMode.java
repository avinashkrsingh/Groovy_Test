package com.smartbear.readyapi4j.execution;

public enum ExecutionMode {
    LOCAL, REMOTE
}
