/**
 * Classes for handling execution results.
 */
package com.smartbear.readyapi4j.result;