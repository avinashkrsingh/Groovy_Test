package com.smartbear.readyapi4j.execution;

public class UnsupportedTestStepException extends RuntimeException {
    public UnsupportedTestStepException(String message) {
        super(message);
    }
}
